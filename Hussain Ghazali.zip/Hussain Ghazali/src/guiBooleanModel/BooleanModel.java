
//HUSSAIN GHAZALI
//K17-3900
//SECTION-A

// THIS IS THE MAIN FILE OF THE CODE 


package guiBooleanModel;

import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;
import java.util.ArrayList;

//CALLING OUT ALL 56 FILES

public class BooleanModel {
    public ArrayList<String> fetchDocuments ( ) throws FileNotFoundException {
        ArrayList<String> collection = new ArrayList<>(); 
        
        collection = fetchFromFile(new File("dataset/speech_0.txt"));
        collection.addAll(fetchFromFile(new File("dataset/speech_1.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_2.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_3.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_4.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_5.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_6.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_7.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_8.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_9.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_10.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_11.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_12.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_13.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_14.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_15.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_16.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_17.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_18.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_19.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_20.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_21.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_22.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_23.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_24.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_25.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_26.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_27.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_28.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_29.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_30.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_31.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_32.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_33.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_34.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_35.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_36.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_37.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_38.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_39.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_40.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_41.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_42.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_43.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_44.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_45.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_46.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_47.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_48.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_49.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_50.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_51.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_52.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_53.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_54.txt")));
        collection.addAll(fetchFromFile(new File("dataset/speech_55.txt")));
        
        return collection;
    } 
    
    // FETCHING THE 56 FILES
    
    public ArrayList<String> fetchFromFile ( File file ) throws FileNotFoundException {
        Scanner sc = new Scanner(file);
        
        String str = "";
        Tokenizer t = new Tokenizer();
        ArrayList<String> collection = new ArrayList<>();
        while ( sc.hasNext() ) {
            String temp = sc.nextLine();
            
            if ( temp.charAt(0) == '[' ) {
                if ( str.length() > 0 ) {
                    collection.add(str);
                    str = "";
                }
                
                str = str + temp + ' ';
            } else {
                temp = t.tokenize(temp);
                str = str + temp + ' ';
            }
        }
        
        if ( !str.isEmpty() ) collection.add(str);
        
        return collection;
    }
    
    // FETCHING STOPWORDS
    
    public ArrayList<String> fetchStopword ( ) throws FileNotFoundException {
        File file = new File("dataset/Stopword-List.txt");
        Scanner sc = new Scanner(file);
        
        ArrayList<String> list = new ArrayList<>();
        while ( sc.hasNext() ) list.add(sc.nextLine());
        
        return list;
    }
    
    // FETCHING QUERY
    
    public ArrayList<String> fetchQuery ( ) throws FileNotFoundException { 
        File file = new File("dataset/QueryList.txt");
        Scanner sc = new Scanner(file);
        
        ArrayList<String> list = new ArrayList<>();
        while ( sc.hasNext() ) list.add(sc.nextLine());
        
        return list;
    }
}
